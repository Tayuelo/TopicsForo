package com.example.usuario.forum.constantes;

public class Constantes {
}
