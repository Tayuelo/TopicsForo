package com.example.usuario.forum.dominio.universidad;

public class UniversidadDominio {

}
