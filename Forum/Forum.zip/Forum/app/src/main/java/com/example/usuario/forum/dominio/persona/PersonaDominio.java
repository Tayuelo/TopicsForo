package com.example.usuario.forum.dominio.persona;

public class PersonaDominio {
}
